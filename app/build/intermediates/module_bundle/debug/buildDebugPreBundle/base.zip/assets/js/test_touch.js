// 添加点击操作
let areas = document.getElementById("image-map").areas;
document.addEventListener("touchstart")